package brito.com.multitenancy001.tenant.api.dto.users.admin;

public record TenantUserAdminSuspendRequest(boolean suspended) {}