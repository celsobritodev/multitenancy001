package brito.com.multitenancy001.platform.domain.tenant;

import lombok.Getter;

@Getter
public enum DocumentType {
    CPF,
    CNPJ;

   
    }
