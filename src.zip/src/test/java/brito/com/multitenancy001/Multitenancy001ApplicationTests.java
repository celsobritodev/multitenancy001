package brito.com.multitenancy001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Multitenancy001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
